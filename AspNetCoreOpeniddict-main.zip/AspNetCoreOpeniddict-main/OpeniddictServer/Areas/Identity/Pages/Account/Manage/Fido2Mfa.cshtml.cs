﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace OpeniddictServer.Areas.Identity.Pages.Account.Manage;

public class MfaModel : PageModel
{
    public void OnGet()
    {
    }

    public void OnPost()
    {
    }
}
