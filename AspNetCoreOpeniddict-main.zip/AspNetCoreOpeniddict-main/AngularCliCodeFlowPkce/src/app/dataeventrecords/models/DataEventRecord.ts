﻿export class DataEventRecord {
    id = 0;
    name = '';
    description = '';
    timestamp = '';
}