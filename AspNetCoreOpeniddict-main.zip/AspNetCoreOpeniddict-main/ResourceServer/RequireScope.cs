﻿using Microsoft.AspNetCore.Authorization;
 
namespace ResourceServer;

public class RequireScope : IAuthorizationRequirement{}