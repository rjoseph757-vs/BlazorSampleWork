﻿namespace BlazorHero.CleanArchitecture.Application.Requests.Identity
{
    public class UpdateProfilePictureRequest : UploadRequest
    {
    }
}