﻿namespace BlazorHero.CleanArchitecture.Application.Features.Products.Queries.GetProductImage
{
    public class GetProductImageResponse
    {
        public string ImageDataURL { get; set; }
    }
}