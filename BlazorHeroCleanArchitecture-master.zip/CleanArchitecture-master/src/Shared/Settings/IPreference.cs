﻿namespace BlazorHero.CleanArchitecture.Shared.Settings
{
    public interface IPreference
    {
        public string LanguageCode { get; set; }
    }
}
