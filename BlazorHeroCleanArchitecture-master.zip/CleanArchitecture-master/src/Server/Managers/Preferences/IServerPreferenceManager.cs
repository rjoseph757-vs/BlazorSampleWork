﻿using BlazorHero.CleanArchitecture.Shared.Managers;

namespace BlazorHero.CleanArchitecture.Server.Managers.Preferences
{
    public interface IServerPreferenceManager : IPreferenceManager
    {
    }
}
