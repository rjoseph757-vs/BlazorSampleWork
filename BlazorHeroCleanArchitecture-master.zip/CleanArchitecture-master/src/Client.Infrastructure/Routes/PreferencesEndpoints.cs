﻿namespace BlazorHero.CleanArchitecture.Client.Infrastructure.Routes
{
    public static class PreferencesEndpoints
    {
        public static string ChangeLanguage = "changeLanguage";

        //TODO - add endpoints
    }
}